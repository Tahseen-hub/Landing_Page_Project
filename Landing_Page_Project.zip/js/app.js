/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
 // Defining Variavbles
const sections = document.querySelectorAll("section");
let navbarlst = document.querySelector("#navbar__list");

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

//Check if the element is in viewport or not
function InViewport(elm) {
	var distance = elm.getBoundingClientRect();

	return (
		distance.top >= -200 &&
		distance.bottom <= (1.5 * window.innerHeight || document.documentElement.clientHeight) &&
		distance.left >= 0 &&
		distance.right <= (window.innerWidth || document.documentElement.clientWidth)
	);
};

//Function to deactivate classes
function deactivateSections() {
    sections.forEach((element)=>{
        element.classList.remove("your-active-class", "active");
    });
}

function deactivateNavLinks() {
    let navbarlnks = document.querySelectorAll(".nav_hyperlink");
    navbarlnks.forEach((element)=>{
        element.classList.remove("active-nav");
    });
}

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the navigation bar ,NavBar
window.addEventListener('load', buildNavbar())

// Add class 'active' to section when comming near top of viewport
function activateٍShownSection(shownSection) {
    shownSection.classList.add("your-active-class", "active");

    deactivateNavLinks();
    activateNavLinks(shownSection.getAttribute('id'));
}

function activateNavLinks(shownSectionId) {
    let navbarlnks = document.querySelectorAll(".nav_hyperlink");
    //console.log(navbarlnks);
        navbarlnks.forEach((element)=>{
            if(element.getAttribute('href') == `#${shownSectionId}`) {
                element.classList.add("active-nav");
            }
        });
}

// Scroll to anchor ID using scrollTO event 
function scrollToSectionOnClick() {
    let navbarlnks = document.querySelectorAll(".nav_hyperlink");
    navbarlnks.forEach((element) => {
        element.addEventListener("click", function(event) {
            event.preventDefault();
            document.querySelector(element.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
}

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu
function buildNavbar() {
	sections.forEach((element)=>{
	    let listItem = document.createElement("li");
	    listItem.classList.add("navbar__list__item");
    	let Sec_Name = element.getAttribute("data-nav");
    	let shownSectionId = element.getAttribute("id");
        listItem.innerHTML = `<a href="#${shownSectionId}" class="nav_hyperlink">${Sec_Name}</a>`;
        navbarlst.appendChild(listItem);
    });
}

// Scroll to section once link clicked
scrollToSectionOnClick();

// Set sections as active
window.addEventListener('scroll', function (event) {
	event.preventDefault();
	
    sections.forEach((element) => {
        // console.log(element);
        if (InViewport(element)) {
            deactivateSections();
            activateٍShownSection(element);
            // console.log('In viewport!');
        } else if(window.scrollY==0) {
            deactivateSections();
            deactivateNavLinks();
            // console.log('Nothing Changed');
        }
    }, false);
});
